<?php $__env->startSection('content'); ?>
<?php
    $u = auth()->user();
    $stepBadge = ['approved' => 'bg-success', 'rejected' => 'bg-danger', 'returned' => 'bg-info', 'pending' => 'bg-warning', 'skipped' => 'bg-light text-muted', 'waiting' => 'bg-light text-muted'];
    $canResume = $r->status === 'approved' && ($u->can('Record staff resumption') || ($own && ! $r->resumed_on && today()->gte($r->start_date)));
    $canCancel = in_array($r->status, ['pending', 'returned', 'approved'], true) && ($r->status !== 'approved' || today()->lt($r->start_date)) && ($own || $u->can('Approve leave for any staff'));
?>
<div class="main-content"><div class="page-content"><div class="container-fluid">
    <?php echo $__env->make('partials.page-title', ['title' => $r->type->name . ' · ' . $r->user->name, 'icon' => 'ri-suitcase-line', 'subtitle' => $r->reference . ' · submitted ' . $r->submitted_at?->format('j M Y H:i'), 'back' => $own ? [route('leave.index'), 'My leave'] : [route('leave.approvals'), 'Approvals']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><?php echo e($errors->first()); ?></div><?php endif; ?>

    <div class="row">
        <div class="col-xl-8">
            <div class="card"><div class="card-header d-flex justify-content-between align-items-center">
                <h6 class="card-title mb-0">Application</h6><span class="badge fs-12 <?php echo e(\App\Models\LeaveRequest::BADGES[$r->status]); ?>"><?php echo e($r->phase); ?></span></div>
                <div class="card-body"><div class="row g-3 fs-13">
                    <div class="col-md-4"><div class="text-muted">Dates</div><strong><?php echo e($r->start_date->format('D j M Y')); ?> – <?php echo e($r->end_date->format('D j M Y')); ?></strong></div>
                    <div class="col-md-4"><div class="text-muted">Days</div><strong><?php echo e($r->days); ?> <?php echo e($r->type->working_days ? 'working' : 'calendar'); ?> day(s)</strong><?php if($r->days_used !== null): ?><div class="text-muted"><?php echo e($r->days_used); ?> used (came back early)</div><?php endif; ?></div>
                    <div class="col-md-4"><div class="text-muted">Expected back</div><strong><?php echo e($r->expected_resumption->format('D j M Y')); ?></strong><?php if($r->resumed_on): ?><div class="<?php echo e($r->late_days ? 'text-danger' : 'text-success'); ?>">Resumed <?php echo e($r->resumed_on->format('j M Y')); ?><?php echo e($r->late_days ? ', ' . $r->late_days . ' working day(s) late' : ''); ?></div><?php endif; ?></div>
                    <div class="col-md-4"><div class="text-muted">Staff</div><?php echo e($r->user->name); ?><?php if($p = $r->user->staffProfile): ?><div class="text-muted"><?php echo e(collect([$p->staff_number, $p->designation, $p->department?->name ?? $p->unit])->filter()->implode(' · ')); ?></div><?php endif; ?></div>
                    <div class="col-md-4"><div class="text-muted">Acting officer</div><?php echo e($r->actingOfficer?->name ?? 'None'); ?><?php if($r->actingOfficer): ?><span class="badge <?php echo e(['accepted' => 'bg-success-subtle text-success', 'declined' => 'bg-danger-subtle text-danger'][$r->acting_status] ?? 'bg-warning-subtle text-warning'); ?>"><?php echo e(ucfirst($r->acting_status ?? 'pending')); ?></span><?php endif; ?></div>
                    <div class="col-md-4"><div class="text-muted">Contact while away</div><?php echo e($r->phone_during_leave ?: '—'); ?><?php if($r->address_during_leave): ?><div class="text-muted"><?php echo e($r->address_during_leave); ?></div><?php endif; ?></div>
                    <?php if($r->reason): ?><div class="col-12"><div class="text-muted">Reason</div><?php echo e($r->reason); ?></div><?php endif; ?>
                    <?php if($r->decision_note): ?><div class="col-12"><div class="text-muted"><?php echo e($r->status === 'approved' ? 'Note' : 'Reason given'); ?></div><?php echo e($r->decision_note); ?></div><?php endif; ?>
                </div></div>
                <?php if($r->warnings): ?>
                    <div class="card-body border-top"><?php $__currentLoopData = $r->warnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="text-warning fs-13"><i class="ri-alert-line me-1"></i><?php echo e($w); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                <?php endif; ?>
            </div>

            <div class="card"><div class="card-header"><h6 class="card-title mb-0">Approval trail</h6></div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item fs-13"><span class="badge bg-primary me-2">Submitted</span><?php echo e($r->user->name); ?> · <?php echo e($r->submitted_at?->format('j M Y H:i')); ?></li>
                    <?php $__currentLoopData = $r->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item fs-13"><span class="badge <?php echo e($stepBadge[$s->status] ?? 'bg-light'); ?> me-2"><?php echo e(ucfirst($s->status)); ?></span><strong><?php echo e($s->label); ?></strong>
                            <?php if($s->actor): ?> · <?php echo e($s->actor->name); ?>, <?php echo e($s->acted_at?->format('j M Y H:i')); ?><?php elseif($s->status === 'pending'): ?> · waiting for <?php echo e($approvers->pluck('name')->implode(', ') ?: 'a leave administrator'); ?><?php if($s->due_at): ?> <span class="<?php echo e($s->due_at->isPast() ? 'text-danger' : 'text-muted'); ?>">(due <?php echo e($s->due_at->format('j M')); ?><?php echo e($s->escalated_at ? ', escalated' : ''); ?>)</span><?php endif; ?> <?php endif; ?>
                            <?php if($s->comment): ?><div class="text-muted ms-1"><?php echo e($s->comment); ?></div><?php endif; ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul></div>

            <?php if($canDecide): ?>
                <div class="card border-warning"><div class="card-header"><h6 class="card-title mb-0">Your decision</h6></div><div class="card-body">
                    <form method="POST" action="<?php echo e(route('leave.decide', $r)); ?>"><?php echo csrf_field(); ?>
                        <textarea name="comment" rows="2" class="form-control mb-2" placeholder="Comment (required to reject or return)"></textarea>
                        <div class="d-flex flex-wrap gap-2">
                            <button name="action" value="approve" class="btn btn-success"><i class="ri-check-line me-1"></i>Approve</button>
                            <button name="action" value="return" class="btn btn-info">Return for correction</button>
                            <button name="action" value="reject" class="btn btn-danger" onclick="return confirm('Refuse this application?')">Do not approve</button>
                        </div>
                    </form>
                </div></div>
            <?php endif; ?>

            <?php if($r->acting_officer_id === $u->id && $r->acting_status === 'pending'): ?>
                <div class="card border-info"><div class="card-body d-flex flex-wrap gap-2 align-items-center"><span class="me-auto"><?php echo e($r->user->name); ?> has named you acting officer.</span>
                    <form method="POST" action="<?php echo e(route('leave.acting', $r)); ?>"><?php echo csrf_field(); ?><input type="hidden" name="accept" value="1"><button class="btn btn-sm btn-success">Accept</button></form>
                    <form method="POST" action="<?php echo e(route('leave.acting', $r)); ?>"><?php echo csrf_field(); ?><input type="hidden" name="accept" value="0"><button class="btn btn-sm btn-light">Decline</button></form></div></div>
            <?php endif; ?>
        </div>

        <div class="col-xl-4">
            <?php if($own && $r->status === 'returned'): ?><a href="<?php echo e(route('leave.edit', $r)); ?>" class="btn btn-primary w-100 mb-3"><i class="ri-edit-line me-1"></i>Correct and resubmit</a><?php endif; ?>

            <?php if($balance): ?>
                <div class="card"><div class="card-body fs-13"><div class="text-muted mb-1"><?php echo e($r->type->name); ?> balance for <?php echo e($r->year); ?></div>
                    <div class="d-flex justify-content-between"><span>Entitled<?php echo e($balance->carried ? ' + carried' : ''); ?></span><strong><?php echo e($balance->allowed()); ?></strong></div>
                    <div class="d-flex justify-content-between"><span>Taken</span><strong><?php echo e($balance->taken); ?></strong></div>
                    <div class="d-flex justify-content-between"><span>Awaiting approval</span><strong><?php echo e($balance->pending); ?></strong></div>
                    <div class="d-flex justify-content-between border-top mt-1 pt-1"><span>Available</span><strong class="<?php echo e($balance->available() < 0 ? 'text-danger' : 'text-success'); ?>"><?php echo e($balance->available() + 0); ?></strong></div></div></div>
            <?php endif; ?>

            <div class="card"><div class="card-header"><h6 class="card-title mb-0">Documents</h6></div>
                <ul class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $r->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item fs-13"><?php if($own || ! $d->confidential || $u->can('View confidential leave documents')): ?><a href="<?php echo e(route('leave.document', $d)); ?>" target="_blank"><i class="ri-file-line me-1"></i><?php echo e($d->original_name); ?></a><?php else: ?><span class="text-muted"><i class="ri-lock-line me-1"></i><?php echo e($r->type->document_label ?: 'Document'); ?> attached (confidential)</span><?php endif; ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-muted fs-13">None attached.</li>
                    <?php endif; ?>
                </ul></div>

            <div class="card"><div class="card-header"><h6 class="card-title mb-0">Letters</h6></div>
                <ul class="list-group list-group-flush"><?php $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li class="list-group-item fs-13"><a href="<?php echo e(route('leave.letter', [$r, $k])); ?>" target="_blank"><i class="ri-printer-line me-1"></i><?php echo e(\App\Support\LeaveLetters::KINDS[$k]); ?></a></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>

            <?php if($canResume): ?>
                <div class="card"><div class="card-header"><h6 class="card-title mb-0">Resumption</h6></div><div class="card-body">
                    <form method="POST" action="<?php echo e(route('leave.resume', $r)); ?>"><?php echo csrf_field(); ?>
                        <label class="form-label fs-12">Resumed on</label><input type="date" name="resumed_on" value="<?php echo e(($r->resumed_on ?? today())->toDateString()); ?>" class="form-control form-control-sm mb-2" required>
                        <input name="note" class="form-control form-control-sm mb-2" placeholder="Note (optional)" value="<?php echo e($r->resumption_note); ?>">
                        <button class="btn btn-sm btn-success w-100"><?php echo e($r->resumed_on ? 'Correct resumption' : 'Record resumption'); ?></button>
                    </form></div></div>
            <?php endif; ?>

            <?php if($canCancel): ?>
                <div class="card"><div class="card-body"><form method="POST" action="<?php echo e(route('leave.cancel', $r)); ?>" onsubmit="return confirm('Cancel this leave?')"><?php echo csrf_field(); ?>
                    <input name="reason" class="form-control form-control-sm mb-2" placeholder="Why it is being cancelled" required>
                    <button class="btn btn-sm btn-outline-danger w-100">Cancel this leave</button></form></div></div>
            <?php endif; ?>

            <?php if($history->isNotEmpty() && ! $own): ?>
                <div class="card"><div class="card-header"><h6 class="card-title mb-0">Recent leave by <?php echo e($r->user->name); ?></h6></div>
                    <ul class="list-group list-group-flush"><?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li class="list-group-item fs-13"><?php echo e($h->type->name); ?> · <?php echo e($h->start_date->format('j M Y')); ?>, <?php echo e($h->days); ?> day(s)</li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
            <?php endif; ?>
        </div>
    </div>
</div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/leave/show.blade.php ENDPATH**/ ?>