/*
 * Score entry tables (results/partials/score-table): marks add up as they are typed.
 *  - a part's assessments (data-item="ca" | "exam") fill its total (data-total); a running sum shows in grey until
 *    every assessment of the part has a mark
 *  - typing a total directly clears that part's assessments, so the total is saved as it is
 *  - typing the overall total (data-grand) clears every assessment and both part totals; the total is saved as typed
 *  - the total and grade (from the university's grade bands on data-bands) follow, with a short highlight
 *  - the header shows how many students are complete, passed, failed and absent, and the average
 *  - "Absent" (data-absent) marks a student who did not sit, told apart from a 0: under the school's "incomplete"
 *    rule (data-absent-policy) the grade shows ABS and no total; under "zero" the marks they have are graded,
 *    missing ones counting 0. Either way the student no longer holds the sheet back
 *  - on an approver's sheet (data-locked) every score is read-only behind a lock icon: clicking it unlocks that score,
 *    clicking again locks it. A form holding the table (data-lock-form) will not save while a score is unlocked, and
 *    the approval form (data-lock-guard) will not go while a score is unlocked or a change is not saved yet
 * Works on pages swapped in without a reload (uv:page) as well as on a full load.
 */
(function () {
    'use strict';
    if (window.UvScores) { return; }
    window.UvScores = true;

    function num(v) { if (v === '' || v === null || v === undefined) { return null; } var n = parseFloat(v); return isNaN(n) ? null : n; }
    function fmt(n) { return n === null ? '' : String(Math.round(n * 100) / 100); }
    function flash(el) { if (!el) { return; } el.classList.remove('uv-flash'); void el.offsetWidth; el.classList.add('uv-flash'); }

    function bandsOf(table) {
        if (!table._bands) { try { table._bands = JSON.parse(table.getAttribute('data-bands') || '[]'); } catch (e) { table._bands = []; } }
        return table._bands;
    }
    function grade(table, total) {
        if (total === null) { return null; }
        var t = Math.round(total * 100) / 100, bands = bandsOf(table);
        for (var i = 0; i < bands.length; i++) { if (t >= bands[i].min && t <= bands[i].max) { return bands[i]; } }
        return null;
    }

    function checkRange(input) {
        var v = num(input.value), max = num(input.getAttribute('max'));
        input.classList.toggle('is-over', v !== null && (v < 0 || (max !== null && v > max)));
    }

    /** What an absent student's total is under the "zero" rule: every mark they have, the rest counting 0. */
    function partialTotal(tr) {
        var grand = tr.querySelector('[data-grand]'), sum = 0, any = false;
        ['ca', 'exam'].forEach(function (part) {
            var items = tr.querySelectorAll('[data-item="' + part + '"]'), totalIn = tr.querySelector('[data-total="' + part + '"]');
            var filled = Array.prototype.filter.call(items, function (i) { return num(i.value) !== null; });
            if (filled.length) { filled.forEach(function (i) { sum += num(i.value); }); any = true; }
            else if (totalIn && num(totalIn.value) !== null) { sum += num(totalIn.value); any = true; }
        });
        if (!any && grand && num(grand.value) !== null) { return num(grand.value); }
        return sum;
    }

    /** Recompute one row. source: the input just typed in, if any. */
    function row(table, tr, source) {
        var absentBox = tr.querySelector('[data-absent]');
        if (absentBox && absentBox.checked) {
            if (table.getAttribute('data-absent-policy') === 'zero') { show(table, tr, partialTotal(tr), source, true); }
            else { show(table, tr, null, source, true); }
            return;
        }
        var parts = {}, complete = true, any = false;
        var grand = tr.querySelector('[data-grand]');
        if (grand && source === grand) {
            // The overall total typed directly: the assessments and the CA and exam totals no longer apply.
            tr.querySelectorAll('[data-item], [data-total]').forEach(function (i) { if (i.value !== '') { i.value = ''; i.classList.remove('is-partial'); flash(i.parentNode); } });
            checkRange(grand);
            show(table, tr, num(grand.value), source);
            return;
        }
        ['ca', 'exam'].forEach(function (part) {
            var items = tr.querySelectorAll('[data-item="' + part + '"]');
            var totalIn = tr.querySelector('[data-total="' + part + '"]');
            var totalText = tr.querySelector('[data-total-text="' + part + '"]');
            var value = null;
            if (source && source === totalIn && items.length) {
                // The lecturer typed the total itself: the assessments of this part no longer apply.
                items.forEach(function (i) { if (i.value !== '') { i.value = ''; flash(i.parentNode); } });
            }
            if (items.length) {
                var sum = 0, filled = 0;
                items.forEach(function (i) { var v = num(i.value); if (v !== null) { sum += v; filled++; } });
                if (filled > 0) {
                    any = true;
                    value = filled === items.length ? sum : null;
                    if (totalIn) {
                        totalIn.value = fmt(sum);
                        totalIn.classList.toggle('is-partial', filled < items.length);
                        totalIn.title = filled < items.length ? filled + ' of ' + items.length + ' assessments entered' : 'Added up from the assessments';
                        if (source && source.getAttribute('data-item') === part) { flash(totalIn.parentNode); }
                    }
                } else if (totalIn) {
                    totalIn.classList.remove('is-partial');
                    value = num(totalIn.value);
                    if (source && source.getAttribute('data-item') === part && totalIn.value !== '' && source.value === '') { totalIn.value = ''; value = null; }
                }
            } else if (totalIn) {
                value = num(totalIn.value);
            } else if (totalText) {
                value = num(totalText.textContent);
            }
            if (totalIn) {
                checkRange(totalIn);
                if (totalIn.classList.contains('is-over')) { totalIn.title = (part === 'ca' ? 'CA' : 'Exam') + ' marks add up to more than ' + totalIn.getAttribute('max'); }
            }
            if (totalIn && totalIn.value !== '') { any = true; }
            parts[part] = value;
            if (value === null) { complete = false; }
        });

        var total = complete ? parts.ca + parts.exam : null;
        if (grand && !source && !any && total === null) {
            // On load, a row with nothing but an overall total (saved that way): keep it.
            total = num(grand.value);
        }
        show(table, tr, total, source);
    }

    function show(table, tr, total, source, absent) {
        var g = grade(table, total);
        var incomplete = absent && total === null;
        var totalOut = tr.querySelector('[data-out="total"]'), gradeOut = tr.querySelector('[data-out="grade"]');
        var isInput = totalOut.tagName === 'INPUT';
        var before = isInput ? totalOut.value : totalOut.textContent;
        if (!(isInput && source === totalOut)) {
            if (isInput) { totalOut.value = fmt(total); } else { totalOut.textContent = fmt(total); }
            if (source && before !== fmt(total)) { flash(totalOut.parentNode); }
        }
        var letter = incomplete ? 'ABS' : (g ? g.grade : '');
        if (gradeOut.textContent !== letter) {
            gradeOut.textContent = letter;
            gradeOut.className = 'uv-grade badge ' + (incomplete ? 'bg-warning-subtle text-warning' : (g ? (g.pass ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger') : ''));
            if (source && (g || incomplete)) { gradeOut.classList.add('uv-pop'); setTimeout(function () { gradeOut.classList.remove('uv-pop'); }, 220); }
        }
        tr.classList.toggle('uv-absent', !!absent);
        tr._state = { total: total, pass: g ? !!g.pass : null, absent: !!absent };
    }

    function summary(table) {
        var rows = table.querySelectorAll('[data-row]'), done = 0, pass = 0, fail = 0, sum = 0, absent = 0, graded = 0;
        rows.forEach(function (tr) {
            var s = tr._state || {};
            if (s.absent) { absent++; done++; if (s.total !== null && s.total !== undefined) { graded++; sum += s.total; if (s.pass) { pass++; } else { fail++; } } return; }
            if (s.total !== null && s.total !== undefined) { done++; graded++; sum += s.total; if (s.pass) { pass++; } else { fail++; } }
        });
        var bar = table.querySelector('[data-progress]'), label = table.querySelector('[data-progress-label]');
        if (bar) { bar.style.width = (rows.length ? Math.round(done * 100 / rows.length) : 0) + '%'; }
        if (label) { label.textContent = done + ' of ' + rows.length + ' students complete'; }
        var set = function (k, v) { var el = table.querySelector('[data-count="' + k + '"]'); if (el) { el.textContent = v; } };
        set('pass', pass); set('fail', fail); set('absent', absent); set('avg', graded ? fmt(sum / graded) : '–');
    }

    function init(root) {
        (root || document).querySelectorAll('[data-score-table]').forEach(function (table) {
            table.querySelectorAll('[data-row]').forEach(function (tr) { row(table, tr, null); });
            summary(table);
        });
    }

    document.addEventListener('change', function (e) {
        var box = e.target;
        if (!box.matches || !box.matches('[data-score-table] [data-absent]')) { return; }
        var table = box.closest('[data-score-table]'), tr = box.closest('[data-row]');
        row(table, tr, box);
        summary(table);
    });

    document.addEventListener('input', function (e) {
        var input = e.target;
        if (!input.matches || !input.matches('[data-item], [data-total], [data-grand]')) { return; }
        var table = input.closest('[data-score-table]'), tr = input.closest('[data-row]');
        if (!table || !tr) { return; }
        checkRange(input);
        row(table, tr, input);
        summary(table);
    });

    // Enter moves down the column, like a spreadsheet, instead of submitting the form.
    document.addEventListener('keydown', function (e) {
        var input = e.target;
        if (e.key !== 'Enter' || !input.matches || !input.matches('[data-score-table] input')) { return; }
        e.preventDefault();
        var td = input.closest('td'), tr = input.closest('tr'), col = Array.prototype.indexOf.call(tr.children, td);
        var next = e.shiftKey ? tr.previousElementSibling : tr.nextElementSibling;
        var target = next && next.children[col] && next.children[col].querySelector('input');
        if (target) { target.focus(); target.select(); }
    });

    /* ------------------------------------------------------------ locks (approver's changes) */

    function setLock(btn, locked) {
        var td = btn.closest('td'), input = td && td.querySelector('input[data-lockable]');
        if (!input) { return; }
        input.readOnly = locked;
        td.classList.toggle('is-unlocked', !locked);
        td.classList.remove('uv-must-lock');
        btn.innerHTML = locked ? '<i class="ri-lock-2-line"></i>' : '<i class="ri-lock-unlock-line"></i>';
        btn.title = locked ? 'Unlock to change this score' : 'Lock this score again';
        btn.setAttribute('aria-label', locked ? 'Unlock' : 'Lock');
        if (!locked) { input.focus(); input.select(); }
    }

    function unlocked(root) { return Array.prototype.slice.call((root || document).querySelectorAll('[data-locked] td.is-unlocked')); }

    function changed(root) {
        return Array.prototype.some.call((root || document).querySelectorAll('[data-locked] input[data-lockable]'), function (i) { return i.value !== i.defaultValue; });
    }

    function nudge(cells) {
        cells.forEach(function (td) { td.classList.remove('uv-must-lock'); void td.offsetWidth; td.classList.add('uv-must-lock'); });
        if (cells[0]) { cells[0].scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    }

    function warn(title, text) {
        if (window.Uv && window.Uv.alert) { window.Uv.alert('warning', title, text); } else { window.console && console.warn(title, text); }
    }

    document.addEventListener('click', function (e) {
        var btn = e.target.closest && e.target.closest('[data-lock]');
        if (!btn) { return; }
        e.preventDefault();
        setLock(btn, btn.closest('td').classList.contains('is-unlocked'));
    });

    // Runs before the page's own submit handling (capture), which skips a submit already stopped here.
    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (!(form instanceof HTMLFormElement)) { return; }
        if (form.hasAttribute('data-lock-form')) {
            var open = unlocked(form);
            if (open.length) {
                e.preventDefault(); e.stopImmediatePropagation();
                nudge(open);
                warn('Lock the scores first', open.length + ' score(s) are still unlocked. Click each open lock to lock it, then save.');
            } else if (!changed(form)) {
                e.preventDefault(); e.stopImmediatePropagation();
                warn('Nothing to save', 'No score has been changed. Unlock a score, change it and lock it again first.');
            }
        } else if (form.hasAttribute('data-lock-guard')) {
            var still = unlocked();
            if (still.length || changed()) {
                e.preventDefault(); e.stopImmediatePropagation();
                if (still.length) { nudge(still); }
                warn(still.length ? 'Lock the scores first' : 'Save your changes first',
                    still.length ? 'Lock every score you unlocked and save your changes before you decide on this sheet.' : 'You changed scores on this sheet. Click Save changes before you decide on it.');
            }
        }
    }, true);

    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', function () { init(); }); } else { init(); }
    document.addEventListener('uv:page', function () { init(); });
    window.UvScoresInit = init;
})();
