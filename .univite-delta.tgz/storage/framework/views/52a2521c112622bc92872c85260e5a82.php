<?php $__env->startSection('content'); ?>
<div class="main-content"><div class="page-content"><div class="container-fluid">
    <?php echo $__env->make('partials.page-title', ['title' => 'Leave balances', 'icon' => 'ri-scales-line', 'subtitle' => 'Entitlement, carry-over, adjustments and days taken for every member of staff.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><?php echo e($errors->first()); ?></div><?php endif; ?>

    <div class="card"><div class="card-header d-flex flex-wrap gap-2 justify-content-between">
        <form method="GET" class="d-flex flex-wrap gap-2">
            <select name="type" class="form-select form-select-sm" style="width:auto"><?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($t->id); ?>" <?php if($type?->id === $t->id): echo 'selected'; endif; ?>><?php echo e($t->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
            <select name="year" class="form-select form-select-sm" style="width:auto"><?php $__currentLoopData = range(now()->year + 1, now()->year - 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option <?php if($y === $year): echo 'selected'; endif; ?>><?php echo e($y); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
            <select name="department_id" class="form-select form-select-sm" style="width:auto;max-width:220px"><option value="">All departments</option><?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($id); ?>" <?php if(request('department_id') == $id): echo 'selected'; endif; ?>><?php echo e($n); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
            <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control form-control-sm" style="width:180px" placeholder="Name">
            <button class="btn btn-sm btn-primary">Show</button>
        </form>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Change leave balances')): ?>
            <form method="POST" action="<?php echo e(route('leave.balances.carryover')); ?>" onsubmit="return confirm('Carry unused days from <?php echo e($year - 1); ?> into <?php echo e($year); ?> for everyone? It is safe to repeat.')"><?php echo csrf_field(); ?><input type="hidden" name="from" value="<?php echo e($year - 1); ?>"><button class="btn btn-sm btn-soft-primary">Carry over <?php echo e($year - 1); ?> → <?php echo e($year); ?></button></form>
        <?php endif; ?>
    </div>
        <div class="table-responsive"><table class="table align-middle mb-0">
            <thead class="table-light"><tr><th>Staff</th><th class="text-end">Entitled</th><th class="text-end">Carried</th><th class="text-end">Adjusted</th><th class="text-end">Taken</th><th class="text-end">Pending</th><th class="text-end">Available</th><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Change leave balances')): ?><th>Adjust</th><?php endif; ?></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $b = $rows[$u->id] ?? null; ?>
                <tr><td><strong><?php echo e($u->name); ?></strong><div class="text-muted fs-12"><?php echo e($u->staffProfile?->department?->name ?? $u->staffProfile?->unit ?? 'No staff profile'); ?></div></td>
                    <?php if($b): ?><td class="text-end"><?php echo e($b->entitled); ?></td><td class="text-end"><?php echo e($b->carried + 0); ?></td><td class="text-end"><?php echo e($b->adjusted + 0); ?></td><td class="text-end"><?php echo e($b->taken); ?></td><td class="text-end"><?php echo e($b->pending); ?></td><td class="text-end fw-semibold"><?php echo e($b->available() + 0); ?></td><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Change leave balances')): ?>
                        <td><form method="POST" action="<?php echo e(route('leave.balances.adjust')); ?>" class="d-flex gap-1"><?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e($u->id); ?>"><input type="hidden" name="leave_type_id" value="<?php echo e($type?->id); ?>"><input type="hidden" name="year" value="<?php echo e($year); ?>">
                            <input type="number" step="0.5" name="days" class="form-control form-control-sm" style="width:70px" placeholder="±days" required>
                            <input name="note" class="form-control form-control-sm" style="width:160px" placeholder="Reason" required>
                            <button class="btn btn-sm btn-light">Save</button></form></td>
                    <?php endif; ?></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">No staff found.</td></tr>
            <?php endif; ?>
            </tbody></table></div>
        <div class="card-body"><?php echo e($staff->links()); ?></div></div>

    <?php if($ledger->isNotEmpty()): ?>
        <div class="card"><div class="card-header"><h6 class="card-title mb-0">Recent carry-overs and adjustments</h6></div>
            <div class="table-responsive"><table class="table table-sm mb-0 fs-13"><tbody>
                <?php $__currentLoopData = $ledger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($l->created_at->format('j M Y')); ?></td><td><?php echo e($l->user?->name); ?></td><td><?php echo e($l->kind === 'carryover' ? 'Carried over' : 'Adjusted'); ?></td><td class="text-end"><?php echo e(sprintf('%+g', $l->days)); ?></td><td><?php echo e($l->note); ?></td><td class="text-muted"><?php echo e($l->creator?->name); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div></div>
    <?php endif; ?>
</div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/leave/balances.blade.php ENDPATH**/ ?>