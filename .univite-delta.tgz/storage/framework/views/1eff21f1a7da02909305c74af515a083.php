<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid" style="max-width:860px">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0"><?php echo e($session->name); ?> <span class="badge bg-<?php echo e(\App\Services\SessionLifecycle::BADGES[$session->status] ?? 'secondary'); ?> ms-2"><?php echo e($lifecycle->label($session->status)); ?></span></h4>
                <a href="<?php echo e(route('academics.sessions.index')); ?>" class="btn btn-sm btn-light"><i class="ri-arrow-left-line me-1"></i>Sessions</a>
            </div>
            <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="card"><div class="card-header"><h5 class="card-title mb-0">Move this session</h5></div>
                <div class="card-body">
                    <p class="text-muted">Draft → Setup → Active → Closing → Closed → Archived. A session is checked before it goes live, and every change is logged.</p>
                    <?php $__empty_1 = true; $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $to => $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <form method="POST" action="<?php echo e(route('sessions.lifecycle.change', $session)); ?>" class="border rounded p-3 mb-3" <?php if($o->needsReason): ?> data-confirm="Change <?php echo e($session->name); ?> to <?php echo e($lifecycle->label($to)); ?>?" <?php endif; ?>>
                            <?php echo csrf_field(); ?> <input type="hidden" name="to" value="<?php echo e($to); ?>">
                            <div class="d-flex align-items-center justify-content-between mb-2"><strong>Move to <?php echo e($lifecycle->label($to)); ?></strong>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Change session status')): ?><button class="btn btn-sm btn-primary" type="submit" <?php if(! $o->allowed()): echo 'disabled'; endif; ?>><?php echo e($lifecycle->label($to)); ?></button><?php endif; ?></div>
                            <?php $__currentLoopData = $o->problems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="text-danger small"><i class="ri-close-circle-line me-1"></i><?php echo e($p); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $o->warnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="text-warning small"><i class="ri-error-warning-line me-1"></i><?php echo e($w); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($o->clean()): ?><div class="text-success small"><i class="ri-checkbox-circle-line me-1"></i>All checks passed.</div><?php endif; ?>
                            <?php if($o->needsReason): ?><input type="text" name="reason" class="form-control form-control-sm mt-2" placeholder="Reason (required)" maxlength="500" required><?php endif; ?>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="mb-0 text-muted">There is nowhere further to move this session.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card"><div class="card-header"><h5 class="card-title mb-0">History</h5></div>
                <div class="table-responsive"><table class="table table-sm align-middle mb-0">
                    <thead class="table-light"><tr><th>When</th><th>Change</th><th>By</th><th>Reason</th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr><td class="text-nowrap"><?php echo e($h->created_at?->format('d M Y, g:i A')); ?></td>
                            <td><?php echo e($h->from_status ? $lifecycle->label($h->from_status) : '—'); ?> → <?php echo e($lifecycle->label($h->to_status)); ?></td>
                            <td><?php echo e($h->user?->name ?? 'System'); ?></td><td><?php echo e($h->reason ?? '—'); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-muted text-center py-3">No changes recorded yet.</td></tr>
                    <?php endif; ?>
                    </tbody></table></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/sessions/lifecycle.blade.php ENDPATH**/ ?>