<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid" style="max-width:900px">
            <div class="page-title-box d-flex justify-content-between align-items-center"><h4 class="mb-0">Generate matric numbers: preview</h4>
                <a href="<?php echo e(route('matric.index')); ?>" class="btn btn-sm btn-light"><i class="ri-arrow-left-line me-1"></i>Matric numbers</a></div>
            <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="alert alert-info mb-3"><strong><?php echo e($preview->total()); ?></strong> student(s) will get a number in the format <code><?php echo e($pattern); ?></code>, in the order below. Nothing has been issued yet.
                If the format is wrong, <a href="<?php echo e(route('students.settings')); ?>">change it first</a>.</div>
            <div class="card">
                <div class="table-responsive" style="max-height:520px"><table class="table table-sm align-middle mb-0">
                    <thead class="table-light"><tr><th>#</th><th>Student</th><th>Programme</th><th>Entry session</th><th>Number</th></tr></thead>
                    <tbody>
                    <?php $__currentLoopData = $preview->rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$s, $number]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><td class="text-muted"><?php echo e($i + 1); ?></td><td><?php echo e($s->full_name); ?></td><td><?php echo e($s->programme?->name); ?></td><td><?php echo e($s->entrySession?->name); ?></td><td><code><?php echo e($number); ?></code></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table></div>
            </div>
            <form method="POST" action="<?php echo e(route('matric.generate')); ?>" class="card"><div class="card-body d-flex justify-content-between align-items-center gap-3">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $preview->rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$s]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><input type="hidden" name="student_ids[]" value="<?php echo e($s->id); ?>"><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="text-muted fs-13">The numbers are issued as one batch. Each student is emailed their number. The batch can be undone, or corrected if the numbers are already in use, from Recent batches.</div>
                <button class="btn btn-primary text-nowrap" type="submit">Issue <?php echo e($preview->total()); ?> number(s)</button>
            </div></form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/students/matric-preview.blade.php ENDPATH**/ ?>