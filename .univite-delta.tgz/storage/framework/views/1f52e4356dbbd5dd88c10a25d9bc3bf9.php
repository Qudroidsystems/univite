<?php $__env->startSection('content'); ?>
<div class="main-content"><div class="page-content"><div class="container-fluid">
    <?php echo $__env->make('partials.page-title', ['title' => 'My leave', 'icon' => 'ri-suitcase-line', 'subtitle' => ($profile?->designation ? $profile->designation . ' · ' : '') . ($profile?->department?->name ?? $profile?->unit ?? '')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="d-flex flex-wrap gap-2 mb-3">
        <a href="<?php echo e(route('leave.create')); ?>" class="btn btn-primary"><i class="ri-add-line me-1"></i>Apply for leave</a>
        <a href="<?php echo e(route('leave.calendar')); ?>" class="btn btn-light"><i class="ri-calendar-line me-1"></i>Leave calendar</a>
        <?php if($waiting): ?><a href="<?php echo e(route('leave.approvals')); ?>" class="btn btn-warning"><i class="ri-inbox-line me-1"></i><?php echo e($waiting); ?> waiting for your decision</a><?php endif; ?>
    </div>

    <?php if($current): ?>
        <?php
            $today = today();
            $starts = $current->start_date; $back = $current->expected_resumption;
            $before = $today->lt($starts); $on = ! $before && $today->lt($back);
            $left = $on ? \App\Services\LeaveService::workingDaysBetween($today, $back->copy()->subDay()) : 0;
            $total = max(1, $starts->diffInDays($back)); $pct = $on ? min(100, round($starts->diffInDays($today) / $total * 100)) : ($before ? 0 : 100);
        ?>
        <div class="card border-<?php echo e($before ? 'info' : ($on ? 'success' : 'danger')); ?>"><div class="card-body">
            <div class="row align-items-center g-3">
                <div class="col-md-3 text-center">
                    <?php if($before): ?>
                        <div class="display-5 fw-semibold text-info"><?php echo e((int) $today->diffInDays($starts)); ?></div><div class="text-muted">day(s) until your leave starts</div>
                    <?php elseif($on): ?>
                        <div class="display-5 fw-semibold text-success"><?php echo e($left); ?></div><div class="text-muted">working day(s) of leave left</div>
                    <?php else: ?>
                        <div class="display-6 fw-semibold text-danger">Due back</div><div class="text-muted">since <?php echo e($back->format('j M')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="col-md-9">
                    <h5 class="mb-1"><a href="<?php echo e(route('leave.show', $current)); ?>"><?php echo e($current->type->name); ?></a> <span class="text-muted fs-13"><?php echo e($current->reference); ?></span></h5>
                    <div class="mb-2"><?php echo e($starts->format('l j M Y')); ?> to <?php echo e($current->end_date->format('l j M Y')); ?> · <?php echo e($current->days); ?> day(s). You are expected back on <strong><?php echo e($back->format('l j M Y')); ?></strong>.</div>
                    <div class="progress" style="height:8px"><div class="progress-bar bg-<?php echo e($before ? 'info' : ($on ? 'success' : 'danger')); ?>" style="width:<?php echo e($pct); ?>%"></div></div>
                    <?php if(! $before): ?>
                        <form method="POST" action="<?php echo e(route('leave.resume', $current)); ?>" class="d-flex flex-wrap gap-2 align-items-end mt-3"><?php echo csrf_field(); ?>
                            <div><label class="form-label fs-12 mb-1">I resumed on</label><input type="date" name="resumed_on" value="<?php echo e(min($today->toDateString(), max($today->toDateString(), $starts->toDateString()))); ?>" max="<?php echo e($today->toDateString()); ?>" class="form-control form-control-sm" required></div>
                            <button class="btn btn-sm btn-success">Confirm my resumption</button>
                            <span class="text-muted fs-12">Coming back early gives the unused days back to your balance.</span>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div></div>
    <?php endif; ?>

    <?php if($acting->isNotEmpty()): ?>
        <div class="card"><div class="card-header"><h6 class="card-title mb-0"><i class="ri-user-shared-line me-1"></i>You are named as acting officer</h6></div>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $acting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex flex-wrap justify-content-between align-items-center gap-2">
                        <div><a href="<?php echo e(route('leave.show', $a)); ?>"><strong><?php echo e($a->user->name); ?></strong></a> · <?php echo e($a->type->name); ?>, <?php echo e($a->start_date->format('j M')); ?> to <?php echo e($a->end_date->format('j M Y')); ?>

                            <span class="badge <?php echo e(['accepted' => 'bg-success-subtle text-success', 'declined' => 'bg-danger-subtle text-danger'][$a->acting_status] ?? 'bg-warning-subtle text-warning'); ?>"><?php echo e(ucfirst($a->acting_status ?? 'pending')); ?></span></div>
                        <?php if($a->acting_status === 'pending'): ?>
                            <div class="d-flex gap-1">
                                <form method="POST" action="<?php echo e(route('leave.acting', $a)); ?>"><?php echo csrf_field(); ?><input type="hidden" name="accept" value="1"><button class="btn btn-sm btn-success">Accept</button></form>
                                <form method="POST" action="<?php echo e(route('leave.acting', $a)); ?>"><?php echo csrf_field(); ?><input type="hidden" name="accept" value="0"><button class="btn btn-sm btn-light">Decline</button></form>
                            </div>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul></div>
    <?php endif; ?>

    <div class="card"><div class="card-header d-flex justify-content-between align-items-center"><h6 class="card-title mb-0">Balances for <?php echo e($year); ?></h6>
        <form method="GET"><select name="year" class="form-select form-select-sm" onchange="this.form.submit()"><?php $__currentLoopData = range(now()->year + 1, now()->year - 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option <?php if($y === $year): echo 'selected'; endif; ?>><?php echo e($y); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></form></div>
        <div class="table-responsive"><table class="table align-middle mb-0">
            <thead class="table-light"><tr><th>Leave type</th><th class="text-end">Entitled</th><th class="text-end">Carried over</th><th class="text-end">Adjusted</th><th class="text-end">Taken</th><th class="text-end">Awaiting approval</th><th class="text-end">Available</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $balances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td><strong><?php echo e($b['type']->name); ?></strong><?php if (! ($b['type']->deducts_balance)): ?><div class="text-muted fs-12">Granted per case, not from a yearly balance</div><?php endif; ?></td>
                    <td class="text-end"><?php echo e($b['balance']->entitled); ?></td><td class="text-end"><?php echo e($b['balance']->carried + 0 ?: '—'); ?></td><td class="text-end"><?php echo e($b['balance']->adjusted + 0 ?: '—'); ?></td>
                    <td class="text-end"><?php echo e($b['balance']->taken ?: '—'); ?></td><td class="text-end"><?php echo e($b['balance']->pending ?: '—'); ?></td>
                    <td class="text-end fw-semibold <?php echo e($b['balance']->available() <= 0 ? 'text-danger' : 'text-success'); ?>"><?php echo e($b['type']->deducts_balance ? $b['balance']->available() + 0 : '—'); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody></table></div></div>

    <div class="card"><div class="card-header"><h6 class="card-title mb-0">My applications</h6></div>
        <div class="table-responsive"><table class="table align-middle mb-0">
            <thead class="table-light"><tr><th>Reference</th><th>Leave</th><th>Dates</th><th>Days</th><th>Where it stands</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td><a href="<?php echo e(route('leave.show', $r)); ?>" class="fw-semibold"><?php echo e($r->reference); ?></a></td><td><?php echo e($r->type->name); ?></td>
                    <td><?php echo e($r->start_date->format('j M')); ?> – <?php echo e($r->end_date->format('j M Y')); ?></td><td><?php echo e($r->days); ?></td>
                    <td><span class="badge <?php echo e(\App\Models\LeaveRequest::BADGES[$r->status]); ?>"><?php echo e($r->phase); ?></span>
                        <?php if($r->status === 'pending' && ($s = $r->currentStep())): ?><div class="text-muted fs-12">With: <?php echo e($s->label); ?></div><?php endif; ?>
                        <?php if($r->status === 'returned'): ?><div><a href="<?php echo e(route('leave.edit', $r)); ?>" class="fs-12">Correct and resubmit</a></div><?php endif; ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center text-muted py-4">You have not applied for leave yet.</td></tr>
            <?php endif; ?>
            </tbody></table></div></div>
</div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/leave/index.blade.php ENDPATH**/ ?>