<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid" style="max-width:880px">
            <div class="d-flex justify-content-between align-items-center mb-3 d-print-none">
                <h4 class="mb-0"><?php echo e($mine ? 'My results' : 'Transcript'); ?></h4>
                <div class="d-flex gap-2"><a href="<?php echo e($mine ? route('dashboard') : route('students.show', $student->id)); ?>" class="btn btn-light">Back</a><button class="btn btn-primary" onclick="window.print()"><i class="ri-printer-line me-1"></i>Print</button></div>
            </div>
            <div class="card"><div class="card-body">
                <?php echo $__env->make('partials.letterhead', ['subtitle' => ($mine ? 'Statement of results' : 'Academic transcript')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <table class="table table-sm">
                    <tr><th style="width:25%">Name</th><td><?php echo e($student->full_name); ?></td><th style="width:20%">Matric number</th><td><?php echo e($student->matric_label); ?></td></tr>
                    <tr><th>Programme</th><td><?php echo e($student->programme->name); ?></td><th>Entry session</th><td><?php echo e($student->entrySession->name); ?></td></tr>
                    <?php if($student->graduated_at): ?>
                        <tr><th>Graduated</th><td><?php echo e($student->graduated_at->format('j M Y')); ?></td><th>Class of degree</th><td><?php echo e($student->degree_class ?? '—'); ?> (CGPA <?php echo e(number_format($student->final_cgpa, 2)); ?>)</td></tr>
                    <?php endif; ?>
                </table>

                <?php if($bf = $t->broughtForward): ?>
                    <h6 class="mt-4">Brought forward from earlier records<?php echo e($bf->asOf ? ' (to the end of ' . $bf->asOf . ')' : ''); ?></h6>
                    <table class="table table-sm"><tbody>
                        <tr><th style="width:25%">Total units (TNU)</th><td><?php echo e($bf->tnu); ?></td><th style="width:25%">Total credit points (TCP)</th><td><?php echo e(rtrim(rtrim(number_format($bf->tcp, 2), '0'), '.')); ?></td></tr>
                        <tr><th>CGPA at that point</th><td><?php echo e(number_format($bf->cgpa, 2)); ?></td><th>Units passed</th><td><?php echo e($bf->unitsPassed ?? '—'); ?></td></tr>
                        <?php if($bf->note): ?><tr><th>Note</th><td colspan="3"><?php echo e($bf->note); ?></td></tr><?php endif; ?>
                    </tbody></table>
                <?php endif; ?>

                <?php $__empty_1 = true; $__currentLoopData = $t->terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <h6 class="mt-4"><?php echo e($term->session->name); ?> · <?php echo e($term->semester->name); ?></h6>
                    <table class="table table-sm">
                        <thead class="table-light"><tr><th>Code</th><th>Title</th><th class="text-end">Units</th><th class="text-end">Score</th><th>Grade</th><th class="text-end">Points</th><?php if($mine): ?><th class="d-print-none"></th><?php endif; ?></tr></thead>
                        <tbody>
                        <?php $__currentLoopData = $term->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td><?php echo e($r->course->code); ?></td><td><?php echo e($r->course->title); ?></td><td class="text-end"><?php echo e($r->credit_units); ?></td><td class="text-end"><?php echo e($r->total); ?></td><td><?php echo e($r->grade); ?></td><td class="text-end"><?php echo e(rtrim(rtrim(number_format($r->points, 2), '0'), '.')); ?></td>
                                <?php if($mine): ?>
                                    <?php $q = $complaints->get($r->id)?->first(); ?>
                                    <td class="d-print-none text-end">
                                        <?php if($q): ?><span class="badge <?php echo e(\App\Models\ResultComplaint::BADGES[$q->status]); ?>">Query: <?php echo e(\App\Models\ResultComplaint::STATUSES[$q->status]); ?></span><?php endif; ?>
                                        <?php if($canQuery($r)): ?><button type="button" class="btn btn-sm btn-link p-0 ms-1" data-bs-toggle="collapse" data-bs-target="#query<?php echo e($r->id); ?>">Query this result</button><?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                            <?php if($mine && $q && $q->response): ?>
                                <tr class="d-print-none"><td colspan="7" class="fs-12 text-muted border-0 pt-0">Answer to your query: <?php echo e($q->response); ?></td></tr>
                            <?php endif; ?>
                            <?php if($mine && $canQuery($r)): ?>
                                <tr class="collapse d-print-none" id="query<?php echo e($r->id); ?>"><td colspan="7">
                                    <form method="POST" action="<?php echo e(route('my.results.query', $r->id)); ?>" class="d-flex gap-2">
                                        <?php echo csrf_field(); ?>
                                        <input name="reason" class="form-control form-control-sm" maxlength="2000" placeholder="What do you think is wrong with this result? (e.g. my CA score is missing)" required>
                                        <button class="btn btn-sm btn-primary text-nowrap" type="submit">Send query</button>
                                    </form>
                                </td></tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot><tr><th colspan="2" class="text-end">Semester GPA</th><th class="text-end"><?php echo e($term->units); ?></th><th colspan="3" class="text-end"><?php echo e(number_format($term->gpa, 2)); ?></th><?php if($mine): ?><th class="d-print-none"></th><?php endif; ?></tr></tfoot>
                    </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php if (! ($t->broughtForward)): ?><p class="text-center text-muted my-5">No results have been published yet.</p><?php endif; ?>
                <?php endif; ?>

                <?php if($t->hasRecords()): ?>
                    <div class="border rounded p-3 bg-light d-flex flex-wrap gap-4">
                        <div><div class="text-muted fs-12">CGPA</div><div class="fs-4 fw-semibold"><?php echo e(number_format($t->cgpa, 2)); ?></div></div>
                        <div><div class="text-muted fs-12"><?php echo e($t->method === 'all' ? 'TNU (all attempts)' : 'Units attempted'); ?></div><div class="fs-4 fw-semibold"><?php echo e($t->units); ?></div></div>
                        <div><div class="text-muted fs-12">TCP</div><div class="fs-4 fw-semibold"><?php echo e(rtrim(rtrim(number_format($t->tcp, 2), '0'), '.')); ?></div></div>
                        <div><div class="text-muted fs-12">Units passed</div><div class="fs-4 fw-semibold"><?php echo e($t->earned); ?></div></div>
                        <?php if($t->class): ?><div><div class="text-muted fs-12">Class</div><div class="fs-4 fw-semibold"><?php echo e($t->class); ?></div></div><?php endif; ?>
                        <?php if($t->standing): ?><div><div class="text-muted fs-12">Academic standing</div><div class="fs-4 fw-semibold text-danger"><?php echo e($t->standing); ?></div></div><?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php if (! ($mine)): ?><?php echo $__env->make('partials.signatory', ['role' => 'registrar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endif; ?>
            </div></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/results/transcript.blade.php ENDPATH**/ ?>