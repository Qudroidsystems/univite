<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="page-title-box"><h4 class="mb-0">Results</h4></div>
            <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if($mine->isNotEmpty() || $mySheets->isNotEmpty()): ?>
                <div class="card">
                    <div class="card-header"><h6 class="card-title mb-0">My courses<?php echo e($ctx ? ' · ' . $ctx->session->name . ' ' . $ctx->type->name : ''); ?></h6></div>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $mine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span><span class="fw-semibold"><?php echo e($a->course->code); ?></span> <?php echo e($a->course->title); ?></span>
                                <a href="<?php echo e(route('results.open', $a->course_id)); ?>" class="btn btn-sm btn-primary">Enter scores</a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php if($mySheets->isNotEmpty()): ?>
                        <div class="card-body border-top pt-2">
                            <div class="text-muted fs-12 mb-1">Recent sheets</div>
                            <?php $__currentLoopData = $mySheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('results.sheets.show', $s->id)); ?>" class="d-block py-1"><?php echo e($s->course->code); ?> · <?php echo e($s->session->name); ?> <?php echo e($s->semesterType->name); ?> <span class="badge <?php echo e(\App\Models\ResultSheet::BADGES[$s->status]); ?> ms-1"><?php echo e(\App\Models\ResultSheet::STATUSES[$s->status]); ?></span></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if($all): ?>
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-pills">
                            <?php $__currentLoopData = ['submitted' => 'Awaiting approval', 'approved' => 'Ready to publish', 'published' => 'Published', 'draft' => 'Drafts', 'all' => 'All']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item"><a class="nav-link <?php echo e($status === $k ? 'active' : ''); ?>" href="<?php echo e(route('results.sheets.index', ['status' => $k])); ?>"><?php echo e($l); ?><?php if($k !== 'all'): ?> <span class="badge bg-light text-body ms-1"><?php echo e($counts[$k] ?? 0); ?></span><?php endif; ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light"><tr><th>Course</th><th>Session</th><th>Students</th><th>Status</th><th></th></tr></thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><span class="fw-semibold"><?php echo e($s->course->code); ?></span> <?php echo e($s->course->title); ?></td>
                                    <td><?php echo e($s->session->name); ?> · <?php echo e($s->semesterType->name); ?></td>
                                    <td><?php echo e($s->results_count); ?></td>
                                    <td><span class="badge <?php echo e(\App\Models\ResultSheet::BADGES[$s->status]); ?>"><?php echo e(\App\Models\ResultSheet::STATUSES[$s->status]); ?></span><?php if($s->stage): ?><div class="text-muted fs-12">At: <?php echo e($s->stage->name); ?></div><?php endif; ?></td>
                                    <td class="text-end"><a class="btn btn-sm btn-soft-primary" href="<?php echo e(route('results.sheets.show', $s->id)); ?>">Open</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center text-muted py-5">No score sheets here.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($all->hasPages()): ?><div class="card-footer"><?php echo e($all->links()); ?></div><?php endif; ?>
                </div>
            <?php elseif($mine->isEmpty() && $mySheets->isEmpty()): ?>
                <div class="alert alert-info">You have no courses assigned this semester.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/results/index.blade.php ENDPATH**/ ?>