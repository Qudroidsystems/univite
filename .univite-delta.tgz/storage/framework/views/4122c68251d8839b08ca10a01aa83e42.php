<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid" style="max-width:900px">
            <div class="page-title-box d-flex justify-content-between align-items-center"><h4 class="mb-0">Generate invoices: preview</h4>
                <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-sm btn-light"><i class="ri-arrow-left-line me-1"></i>Invoices</a></div>
            <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <p class="text-muted"><?php echo e($session->name); ?><?php echo e($semester ? ' · ' . $semester->name . ' fees' : ' · session fees'); ?> · <?php echo e($programme?->name ?? 'All programmes'); ?> · <?php echo e(isset($data['level']) ? \App\Support\Levels::label((int) $data['level']) : 'All levels'); ?>. Nothing has been created yet.</p>
            <div class="row g-3 mb-3">
                <div class="col-sm-3"><div class="card mb-0"><div class="card-body"><div class="text-muted fs-12">Invoices to create</div><div class="fs-3 fw-semibold text-primary"><?php echo e($preview->create); ?></div></div></div></div>
                <div class="col-sm-3"><div class="card mb-0"><div class="card-body"><div class="text-muted fs-12">Total billed</div><div class="fs-5 fw-semibold">₦<?php echo e(number_format($preview->amount, 2)); ?></div></div></div></div>
                <div class="col-sm-3"><div class="card mb-0"><div class="card-body"><div class="text-muted fs-12">Skipped: already invoiced</div><div class="fs-3 fw-semibold"><?php echo e($preview->existing); ?></div></div></div></div>
                <div class="col-sm-3"><div class="card mb-0"><div class="card-body"><div class="text-muted fs-12">Skipped: no matching bills</div><div class="fs-3 fw-semibold text-warning"><?php echo e($preview->noBills); ?></div></div></div></div>
            </div>
            <?php if($preview->noBills): ?><div class="alert alert-warning"><?php echo e($preview->noBills); ?> active student(s) have no school bills that match them (programme, level, nationality, fresh or returning). Add the bills first if they should be invoiced.</div><?php endif; ?>
            <?php if($preview->sample): ?>
                <div class="card"><div class="card-header"><h6 class="card-title mb-0">First <?php echo e(count($preview->sample)); ?> of <?php echo e($preview->create); ?></h6></div>
                    <div class="table-responsive"><table class="table table-sm mb-0"><thead class="table-light"><tr><th>Student</th><th>Matric number</th><th class="text-end">Amount</th></tr></thead><tbody>
                        <?php $__currentLoopData = $preview->sample; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name, $matric, $amount]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($name); ?></td><td><?php echo e($matric); ?></td><td class="text-end">₦<?php echo e(number_format($amount, 2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody></table></div></div>
            <?php endif; ?>
            <?php if($preview->create): ?>
                <form method="POST" action="<?php echo e(route('invoices.generate')); ?>" class="card"><div class="card-body d-flex justify-content-between align-items-center gap-3">
                    <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>"><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-muted fs-13">The run is recorded as one operation. While nobody has paid, it can be reversed from the operation history and the invoices are cancelled (kept on record).</div>
                    <button class="btn btn-primary text-nowrap" type="submit">Create <?php echo e($preview->create); ?> invoice(s)</button>
                </div></form>
            <?php else: ?>
                <div class="alert alert-secondary">There is nothing to create.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/invoices/generate-preview.blade.php ENDPATH**/ ?>