<?php $__env->startSection('content'); ?>
<?php
    $editable = $form && $form->isEditable() && ! $blockers;
    $chosen = old('courses', $form ? $form->courses->pluck('course_id')->all() : []);
?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid" style="max-width:900px">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="mb-0">Course registration</h4>
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-light">Back</a>
            </div>
            <?php echo $__env->make('academics.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if(! $ctx): ?>
                <div class="alert alert-info">No semester is running right now. Registration opens when the university starts a semester.</div>
            <?php else: ?>
                <p class="text-muted"><?php echo e($ctx->session->name); ?> · <?php echo e($ctx->type->name); ?> · <?php echo e($student->current_level); ?> level · <?php echo e($student->programme->name); ?></p>
            <?php endif; ?>

            <?php $__currentLoopData = $blockers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-warning mb-2"><?php echo e($b); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($form && $form->status !== 'draft'): ?>
                <div class="alert <?php echo e($form->status === 'approved' ? 'alert-success' : ($form->status === 'rejected' ? 'alert-danger' : 'alert-info')); ?> d-flex justify-content-between align-items-center">
                    <span>
                        <strong><?php echo e(\App\Models\RegistrationForm::STATUSES[$form->status]); ?>.</strong>
                        <?php if($form->status === 'submitted'): ?> Your registration is with the approving officer. <?php endif; ?>
                        <?php if($form->status === 'rejected'): ?> Your form was returned: <?php echo e($form->note); ?> Change your courses and submit again. <?php endif; ?>
                    </span>
                    <?php if($form->status === 'approved'): ?><a href="<?php echo e(route('my.registration.print', $form->id)); ?>" class="btn btn-sm btn-success"><i class="ri-printer-line me-1"></i>Print form</a><?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if($form && ($editable || $form->status !== 'draft' || $form->courses->isNotEmpty())): ?>
            <form method="POST" action="<?php echo e(route('my.registration.save')); ?>" id="reg-form">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="card-title mb-0">Courses for this semester</h6>
                        <span class="badge bg-primary-subtle text-primary fs-13"><span id="units">0</span> units · allowed <?php echo e($limits->min); ?>–<?php echo e($limits->max); ?><?php if($limits->probation): ?> <span class="text-danger">(reduced: you are on probation)</span><?php endif; ?> <?php if($limits->carryoversExempt): ?> <span class="text-muted">(carry-overs not counted in the maximum)</span><?php endif; ?></span>
                    </div>
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead class="table-light"><tr><th style="width:1%"></th><th>Course</th><th>Status</th><th class="text-end">Units</th></tr></thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $offered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php $c = $o['course']; $on = in_array($c->id, $chosen); ?>
                                <tr class="<?php echo e($o['blocked'] ? 'text-muted' : ''); ?>">
                                    <td><input type="checkbox" class="form-check-input course-box" name="courses[]" value="<?php echo e($c->id); ?>" data-units="<?php echo e($c->credit_units); ?>" data-carry="<?php echo e($o['carryover'] ? 1 : 0); ?>" <?php if($on): echo 'checked'; endif; ?> <?php if(! $editable || $o['blocked']): echo 'disabled'; endif; ?>></td>
                                    <td><span class="fw-semibold"><?php echo e($c->code); ?></span> <?php echo e($c->title); ?>

                                        <?php if($o['carryover']): ?><span class="badge bg-danger-subtle text-danger ms-1">Carry-over</span><?php endif; ?>
                                        <?php if($o['blocked']): ?><div class="fs-12 text-danger"><?php echo e($o['blocked']); ?></div><?php endif; ?></td>
                                    <td><?php echo e(\App\Support\Lookups::label('course_status', $o['status'])); ?></td>
                                    <td class="text-end"><?php echo e($c->credit_units); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="text-center text-muted py-4">No courses are set up for your programme at this level and semester yet.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($editable): ?>
                        <?php $__currentLoopData = $problems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="px-3 pt-2 text-danger fs-13"><?php echo e($p); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-footer d-flex gap-2 justify-content-end">
                            <button class="btn btn-light" type="submit"><i class="ri-save-line me-1"></i>Save selection</button>
                            <button class="btn btn-primary" type="submit" name="submit" value="1" data-confirm="Submit your course registration? You will not be able to change it unless it is returned to you."><i class="ri-send-plane-line me-1"></i>Submit registration</button>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
            <?php endif; ?>

            <?php if($history->count() > 1): ?>
                <div class="card"><div class="card-header"><h6 class="card-title mb-0">Earlier registrations</h6></div>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($form && $h->id === $form->id) continue; ?>
                            <li class="list-group-item d-flex justify-content-between"><span><?php echo e($h->session->name); ?> · <?php echo e($h->semesterType->name); ?> · <?php echo e($h->total_units); ?> units</span>
                                <span><?php if($h->status === 'approved'): ?><a href="<?php echo e(route('my.registration.print', $h->id)); ?>">Print</a><?php else: ?><span class="badge <?php echo e(\App\Models\RegistrationForm::BADGES[$h->status]); ?>"><?php echo e(\App\Models\RegistrationForm::STATUSES[$h->status]); ?></span><?php endif; ?></span></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    function tally() {
        var t = 0;
        document.querySelectorAll('.course-box:checked').forEach(function (b) { t += parseInt(b.dataset.units, 10) || 0; });
        var el = document.getElementById('units'); if (el) el.textContent = t;
    }
    document.querySelectorAll('.course-box').forEach(function (b) { b.addEventListener('change', tally); });
    tally();
})();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/univite/resources/views/registration/mine.blade.php ENDPATH**/ ?>